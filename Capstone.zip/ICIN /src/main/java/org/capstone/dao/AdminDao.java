package org.capstone.dao;


import org.capstone.model.Admin;

public interface AdminDao {
	

	int validateadmin(String aid, String pass);


}
